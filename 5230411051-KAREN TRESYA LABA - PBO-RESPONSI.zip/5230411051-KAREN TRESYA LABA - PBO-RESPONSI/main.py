import mysql.connector
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QLineEdit, QLabel, QHBoxLayout

class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

class Transaction:
    def __init__(self, product_id, quantity, total_price, date):
        self.product_id = product_id
        self.quantity = quantity
        self.total_price = total_price
        self.date = date

class ProductController:
    def __init__(self):
        # Membuat koneksi ke database dan cursor
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",                # Username sesuai dengan yang digunakan
            password="",         # Password sesuai dengan yang digunakan
            database="tabel produk"      # Pastikan database benar
        )
        self.cursor = self.conn.cursor()  # Membuat objek cursor untuk mengeksekusi query

    # CRUD untuk Produk
    def create_product(self, product):
        query = "INSERT INTO produk (nama_produk, harga_produk) VALUES (%s, %s)"
        self.cursor.execute(query, (product.name, product.price))
        self.conn.commit()

    def read_products(self):
        query = "SELECT * FROM produk"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def update_product(self, product_id, new_name, new_price):
        query = "UPDATE produk SET nama_produk=%s, harga_produk=%s WHERE id_produk=%s"
        self.cursor.execute(query, (new_name, new_price, product_id))
        self.conn.commit()

    def delete_product(self, product_id):
        query = "DELETE FROM produk WHERE id_produk=%s"
        self.cursor.execute(query, (product_id,))
        self.conn.commit()

    # CRUD untuk Transaksi
    def create_transaction(self, transaction):
        query = """
        INSERT INTO transaksi (id_produk, jumlah_produk, total_harga, tanggal_transaksi) 
        VALUES (%s, %s, %s, %s)
        """
        self.cursor.execute(query, (transaction.product_id, transaction.quantity, transaction.total_price, transaction.date))
        self.conn.commit()

    def read_transactions(self):
        query = """
        SELECT t.id_transaksi, p.nama_produk, t.jumlah_produk, t.total_harga, t.tanggal_transaksi
        FROM transaksi t
        JOIN produk p ON t.id_produk = p.id_produk
        """
        self.cursor.execute(query)
        return self.cursor.fetchall()

    # Menutup koneksi dan cursor setelah penggunaan
    def close(self):
        self.cursor.close()
        self.conn.close()


class ProductGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.controller = ProductController()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Manajemen Produk & Transaksi")
        self.layout = QVBoxLayout()

        # Produk Management
        self.product_table = QTableWidget()
        self.layout.addWidget(QLabel("Data Produk"))
        self.layout.addWidget(self.product_table)

        self.load_product_button = QPushButton("Muat Data Produk")
        self.load_product_button.clicked.connect(self.load_products)
        self.layout.addWidget(self.load_product_button)

        # Transaksi Management
        self.transaction_table = QTableWidget()
        self.layout.addWidget(QLabel("Data Transaksi"))
        self.layout.addWidget(self.transaction_table)

        self.load_transaction_button = QPushButton("Muat Data Transaksi")
        self.load_transaction_button.clicked.connect(self.load_transactions)
        self.layout.addWidget(self.load_transaction_button)

        self.setLayout(self.layout)

    def load_products(self):
        products = self.controller.read_products()
        self.product_table.setRowCount(len(products))
        self.product_table.setColumnCount(3)
        self.product_table.setHorizontalHeaderLabels(["ID", "Nama Produk", "Harga"])

        for row_idx, row_data in enumerate(products):
            for col_idx, col_data in enumerate(row_data):
                self.product_table.setItem(row_idx, col_idx, QTableWidgetItem(str(col_data)))

    def load_transactions(self):
        transactions = self.controller.read_transactions()
        self.transaction_table.setRowCount(len(transactions))
        self.transaction_table.setColumnCount(5)
        self.transaction_table.setHorizontalHeaderLabels(
            ["ID Transaksi", "Nama Produk", "Jumlah Produk", "Total Harga", "Tanggal"]
        )

        for row_idx, row_data in enumerate(transactions):
            for col_idx, col_data in enumerate(row_data):
                self.transaction_table.setItem(row_idx, col_idx, QTableWidgetItem(str(col_data)))

    def closeEvent(self, event):
        # Menutup koneksi ketika aplikasi ditutup
        self.controller.close()
        event.accept()

if __name__ == "__main__":
    app = QApplication([])
    window = ProductGUI()
    window.show()
    app.exec_()
